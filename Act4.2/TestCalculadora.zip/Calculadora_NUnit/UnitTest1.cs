using Calculadora_NUnit;

namespace Calculadora_NUnit
{
    // Calculadora.cs
    public class Calculadora
    {
        public int Sumar(int a, int b)
        {
            return a + b;
        }
    }
}