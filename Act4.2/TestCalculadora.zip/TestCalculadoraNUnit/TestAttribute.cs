﻿using System;

namespace TestCalculadoraNUnit
{
    internal class TestAttribute : Attribute
    {
    }
}